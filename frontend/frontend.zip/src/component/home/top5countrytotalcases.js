import React, { useEffect, useState } from 'react';
import { Box, Divider, IconButton, List, ListItem, ListItemButton, MenuItem, Stack, SwipeableDrawer, Tab, Tabs, TextField, Typography } from '@mui/material';
import {
    Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title
} from 'chart.js';
import { Bar, Doughnut, Pie } from 'react-chartjs-2';
import { useDispatch, useSelector } from 'react-redux';
import { getData } from '../../store/actions/dataAction';
import moment from 'moment/moment';
import { Loader } from '../../component/loader';


ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title);



export default function TopFiveTotalCase() {



    const [state, setState] = useState({

        labels: [],
        datasets: [
            {
                label: '# of Votes',
                data: [],
                backgroundColor: [
                ],
                borderColor: [

                ],
                borderWidth: 1,
            },
        ],
    }
    );



    const dispatch = useDispatch()


    const { data, loading } = useSelector((state) => state.data);

    console.log(data);

    useEffect(() => {
        dispatch(getData(null,null, 1, null));
    }, [dispatch]);




    useEffect(() => {
        if (data?.data) {
            setState({
                labels: data?.data && data?.data?.length > 0 ? data?.data[1]?.map((item) => { return item.SubLocation }) : [],
                datasets: [
                    {
                        label: 'Covid cases',
                        data: data?.data && data?.data?.length > 0 ? data?.data[1]?.map((item) => { return item.Count }) : [],
                        backgroundColor: [
                            "#33b2df",
                            "#546E7A",
                            "#d4526e",
                            "#13d8aa",
                            "#A5978B",
                            "#2b908f",
                            "#f9a3a4",
                            "#90ee7e",
                            "#f48024",
                            "#69d2e7",
                          ],
                        borderColor:[
                            "#33b2df",
                            "#546E7A",
                            "#d4526e",
                            "#13d8aa",
                            "#A5978B",
                            "#2b908f",
                            "#f9a3a4",
                            "#90ee7e",
                            "#f48024",
                            "#69d2e7",
                          ],
                        borderWidth: 1,
                    },
                ],
            });
        }
    }, [data]);

    console.log(state);





    return (
        <>
            
            {state?.labels && <Box sx={{ height: "50vh", width: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
                <Doughnut
                    data={state}
                    

                />
            </Box>}


        </>
    );
}
